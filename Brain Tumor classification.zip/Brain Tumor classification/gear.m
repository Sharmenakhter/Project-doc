%% Counting teeth
% This is an example of how to use Cell Mode in the MATLAB Editor.

%% Read in the image

gearImage = imread('gear.jpg');
imshow(gearImage)


%% Convert to grayscale and threshold

gearGray = rgb2gray(gearImage);
gearBW = gearGray > 120;
imshow(gearBW)


%% Remove the small spots
% Clean up the image.

gearBW = bwareaopen(gearBW, 20);
imshow(gearBW)


%% Fill in the holes 

gearBW = bwfill(gearBW, 'holes');
imshow(gearBW)


%% Find the circle that encloses the gear

rp = regionprops(double(gearBW), 'all');
xy = rp.ConvexHull;
line(xy(:,1),xy(:,2),'Color','yellow','LineWidth',2)


%% Shrink the circle to expose the gears

[r,c] = size(gearBW);
mask = poly2mask(xy(:,1), xy(:,2), r, c);
maskEroded = imerode(mask, ones(16));

rp = regionprops(double(maskEroded), 'all');
xy = rp.ConvexHull;
line(xy(:,1),xy(:,2),'Color','red','LineWidth',2)


%% Subtract the hub

teeth = gearBW;
teeth(maskEroded) = 0;
imshow(teeth)


%% Label and count the teeth
% Output to the MATLAB command window is captured in the HTML file.

[teethLabel, numTeeth] = bwlabel(teeth);
imshow(label2rgb(teethLabel, @prism))
numTeeth
